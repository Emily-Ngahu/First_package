from setuptools import setup , find_packages

setup(
    name = 'MY PACKAGE',
    version = '0.1',
    license= 'MIT',
    description= 'EDSA example pyton package',
    long_description= open('README.md').read(),
    install_requires = ['numpy'],
    url = "",
    author= 'Emily',
    author_email= 'ngahuemily76@gmail.com'
)